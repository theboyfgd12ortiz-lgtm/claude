---
title: RTK Documentation
description: RTK (Rust Token Killer) — cut up to 90% of the bash output your agent reads on common dev commands, with zero workflow changes
sidebar:
  order: 1
---

# RTK — Rust Token Killer

RTK is a CLI proxy that sits between your AI assistant and your development tools. It filters command output before it reaches the LLM, keeping only what matters and discarding boilerplate, progress bars, and noise.

**Result:** up to 90% fewer bash output bytes reaching the LLM per command, without changing how you work. You run `git status` as usual — RTK's hook intercepts it, filters the output, and the LLM sees a compact 3-line summary instead of 40 lines.

## How it works

```
Your AI assistant runs:  git status
                              ↓
              Hook intercepts (PreToolUse)
                              ↓
              rtk git status  (transparent rewrite)
                              ↓
     Raw output: 40 lines     →     Filtered: 3 lines
                              ↓
              LLM sees the compact output
```

Zero config changes to your workflow. The hook handles everything automatically.

## What the savings mean

RTK reduces **bash output bytes** — the output a shell command sends back before your agent reads it. That is not the same as reducing your bill by the same amount.

Bash output is one contributor to input tokens, alongside your prompt, the system prompt and conversation history. Input tokens are in turn only part of the bill, which also counts output tokens. The reduction dilutes at every step.

See [How RTK Savings Work](./resources/savings-explained.md) for the full picture, including why the token counts RTK reports are estimates.

## What RTK optimizes

Dozens of commands across all major ecosystems — Git, Cargo/Rust, JavaScript, Python, Go, Ruby, .NET, Docker/Kubernetes, and more. See [What RTK Optimizes](./resources/what-rtk-covers.md) for the full list with per-command bash output reduction.

## Get started

1. **[Installation](./getting-started/installation.md)** — Install RTK and verify you have the right package
2. **[Quick Start](./getting-started/quick-start.md)** — Connect to your AI assistant in 5 minutes
3. **[Supported Agents](./getting-started/supported-agents.md)** — Claude Code, Cursor, Copilot, Gemini, and more

## Measure your savings

```bash
rtk gain           # total savings across all sessions
rtk gain --daily   # day-by-day breakdown
rtk gain --weekly  # weekly aggregation
```

See [Token Savings Analytics](./analytics/gain.md) for export formats and analysis workflows.

## Analyze your usage

```bash
rtk discover       # find commands that ran without RTK (missed savings)
rtk session        # RTK adoption rate per Claude Code session
```

See [Discover and Session](./analytics/discover.md) for details.

## Further reading

- [Configuration](./getting-started/configuration.md) — config.toml, global flags, env vars, recall recovery
- [Troubleshooting](./resources/troubleshooting.md) — common issues and fixes
- [Telemetry & Privacy](./resources/telemetry.md) — what RTK collects and how to opt out
- [ARCHITECTURE.md](https://github.com/rtk-ai/rtk/blob/master/ARCHITECTURE.md) — system design for contributors
