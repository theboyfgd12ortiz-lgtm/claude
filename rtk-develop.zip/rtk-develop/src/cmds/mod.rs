//! Command filter modules organized by language ecosystem.

pub mod cloud;
pub mod dotnet;
pub mod git;
pub mod go;
pub mod js;
pub mod jvm;
pub mod php;
pub mod python;
pub mod ruby;
pub mod rust;
pub mod scala;
pub mod system;
